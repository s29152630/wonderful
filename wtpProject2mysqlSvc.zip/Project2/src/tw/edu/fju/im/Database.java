package tw.edu.fju.im;

import java.sql.*;

public class Database {
	public static String dBase;
	public static String username;
	public static String password;

	public String lookupFullname(String userid) throws SQLException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultset = null;
		String fullname = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(dBase, username, password);
			String QUERY = "SELECT FULLNAME FROM LOGIN WHERE USERID = ?";
			statement = connection.prepareStatement(QUERY);
			statement.setString(1, userid);
			resultset = statement.executeQuery();
			if (resultset.next())
				fullname = resultset.getString("FULLNAME").trim();
			}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally {
			if (resultset != null) resultset.close();
			if (statement != null) statement.close();
			if (connection != null) connection.close();
		}
		return fullname;
	}
}
